#include <stdio.h>
#include <stdlib.h>
#include <complex.h>

#define TAYLOR_TERMS 15
#define M_PI 3.1415926535897932384

double factorial(int n) {
  return n<=1 ? 1.0 : n*factorial(n-1);
}

double elevado(double n, int times) {
  double result=1.0;
  int i;
  for(i=0;i<times;i++) {
    result*=n;
  }
  return result;
}

double modulus_pi(double x) {
  if(x>2*M_PI) {
    do {
      x-=2*M_PI;
    } while(x>2*M_PI);
  } else if(x<0) {
    do {
      x+=2*M_PI;
    } while(x<0);
  }
  return x;
}

double cos_aprox(double x) {
  int i;
  double app=1.0;
  x=modulus_pi(x);
  for(i=1;i<TAYLOR_TERMS;i++) {
    app+= elevado(-1.0,i)*elevado(x, 2*i)/factorial(2*i);
  }
  return app;
}

double sin_aprox(double x) {
  int i;
  double app;
  x=modulus_pi(x);
  app=x;
  for(i=1;i<TAYLOR_TERMS;i++) {
    app+= elevado(-1.0,i)*elevado(x, 2*i+1)/factorial(2*i+1);
  }
  return app;
}

int main(int argc, char *argv[]) {

  int n,k;
  int N = atoi(argv[1]);

  char buf[0x100];
  snprintf(buf, sizeof(buf), "./data/results_%s_elementos.dat", argv[1]);
  FILE *fp = fopen(buf, "wb");
  if (!fp)
    error();

fprintf(fp, "#define num %s\n",argv[1]); 
fprintf(fp, "void dft(complex double* x,complex double* X, int N);\n"); 
fprintf(fp,"double cos_array[%s]=\n{\n",argv[1]);
  for(k=0;k<N;k++) {
   
      double complex w = cos_aprox(2*M_PI*k*n/N)-sin_aprox(2*M_PI*k*n/N)*I;
      fprintf(fp," %lf,\n",creal(w)); 
      
    }
	fprintf(fp,"}\n");

	fprintf(fp,"double complex sin_array[%s]=\n{\n",argv[1]);
	 for(n=0;n<N;n++) {
                double complex w = cos_aprox(2*M_PI*k*n/N)-sin_aprox(2*M_PI*k*n/N)*I;
		fprintf(fp,"%lf*I,\n", cimag(w));

	 }
	fprintf(fp,"}\n");

  
}
