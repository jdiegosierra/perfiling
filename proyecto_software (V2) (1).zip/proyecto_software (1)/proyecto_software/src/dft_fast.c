#include <stdio.h>
#include <stdlib.h>
#include <complex.h>
#include <assert.h>
#include <sys/time.h>
#include "results_1024_elementos.h"

#define MAX_LINE 200
#define TAYLOR_TERMS 15
#define M_PI 3.1415926535897932384

double factorial(int n) {
  return n<=1 ? 1.0 : n*factorial(n-1);
}

double elevado(double n, int times) {
  double result=1.0;
  int i;
  for(i=0;i<times;i++) {
    result*=n;
  }

  return result;
}

double modulus_pi(double x) {
  if(x>2*M_PI) {
    do {
      x-=2*M_PI;
    } while(x>2*M_PI);
  } else if(x<0) {
    do {
      x+=2*M_PI;
    } while(x<0);
  }

  return x;
}

double cos_aprox(double x) {
  int i;
  double app=1.0;
  x=modulus_pi(x);
  for(i=1;i<TAYLOR_TERMS;i++) {
    app+= elevado(-1.0,i)*elevado(x, 2*i)/factorial(2*i);
  }
  return app;
}

double sin_aprox(double x) {
  int i;
  double app;
  x=modulus_pi(x);
  app=x;
  for(i=1;i<TAYLOR_TERMS;i++) {
    app+= elevado(-1.0,i)*elevado(x, 2*i+1)/factorial(2*i+1);
  }
  return app;
}

void dft(complex double* x,complex double* X, int N, double *cos_array, double *sin_array) {
  int n,k;

  for(k=0;k<N;k++) {
    double complex acc = 0;
    for(n=0;n<N;n++) {
      double complex w = cos_array[n]-sin_array[n]*I;
      acc+=x[n]*w;
    }
    X[k]=acc;
  }
}

void print_complex(double complex x) {
  // if(cimag(x)<0) {
  //   printf("%lf - %lfi", creal(x), -cimag(x));
  // } else {
  //   printf("%lf + %lfi", creal(x), cimag(x));
  // }
  printf("(%lf, %lf)", creal(x), cimag(x));
}

void read_results(char path, double *cos_array, double *sin_array) {
  int mem;
  FILE *file;
  file = fopen(path, "r");
  if (file) {
      // Guardar valores del archivo en el array
      // Hay que reservar memoria cada vez que se guarda en el array
      // mem = malloc(n*sizeof(double complex));
      fclose(file);
  }
}

int main() {
  char buffer[MAX_LINE];
  char trailer[MAX_LINE];
  int i;
  int n;
  int ret;
  double complex *x;
  double complex *X;
  double re,im;
  struct timeval s,e;
  double *cos_array, *sin_array;

  do {
    printf("Introduce el valor de n (potencia de 2): ");
    fgets(buffer, MAX_LINE, stdin);
    n=atoi(buffer);
  } while(!(n > 0 && (n & (n - 1)) == 0));

  x=malloc(n*sizeof(double complex));
  X=malloc(n*sizeof(double complex));
  assert(x!=NULL && X!=NULL);

  printf("\nIntroduce el array. Ejemplo para especificar un numero complejo (re,im): \"(1,1)\" representa 1+i.");


  for(i = 0; i < n; i++) {
    do {
      fgets(buffer, MAX_LINE, stdin);
      ret=sscanf(buffer, "(%lf,%lf)%s", &re, &im, trailer);
    } while(ret!=2);
    x[i]=re+im*I;
  }
  gettimeofday(&s, NULL);
  dft(x, X, n, cos_array, sin_array);
  gettimeofday(&e, NULL);
  fprintf(stderr, "Execution time: %f\n",  ((e.tv_sec*1000000+e.tv_usec)-(s.tv_sec*1000000+s.tv_usec))*1.0/100000.0);
  printf("\n\nImprimiendo la DFT:\n");
  for(i = 0; i < n; i++) {
      printf("    x[%d]=", i);
      print_complex(x[i]);
      printf("    X[%d]=", i);
      print_complex(X[i]);
      printf("\n", i);
  }

  free(x);
  free(X);
  return 0;
}
