# Indicaciones generales

El siguiente programa ha sido probado y diseñado para entornos Linux. Hace uso de CMake para la generación de los ficheros y se puede compilar desde una terminal usando el comando:

```
make 
``` 

La invocación del objetivo por defecto creará automáticamente una carpeta 'bin' con un ejecutable 'dft' que puede ser llamado desde una terminal. Ejemplo:

```
▶ ./bin/dft
Introduce el valor de n (potencia de 2):
```

Es decir, en este punto el programa espera que el usuario escriba los valores necesarios para el cálculo de la DFT: número de muestras y valor asignado a cada punto.
- En el caso del número de muestras a tener en cuenta para calcular la DFT, n, el valor debe ser potencia de 2 por motivos de la implementación.
- El valor en cada punto se trata de un número complejo
```
▶ ./bin/dft
Introduce el valor de n (potencia de 2): 4

Introduce el array. Ejemplo para especificar un numero complejo (re,im): "(1,1)" representa 1+i.
    x[0]=
```
- Cada una de las muestras es un número complejo que se indica con la siguiente notación: (parte real, parte imaginaria). Así pues, el valor "2+i" sería representado como "(2,i)".

Tras introducir todos los valores necesarios el programa imprime por la salida estándar el resultado de la transformada discreta.


# Programar tests automáticos

Los datos a introducir por el usuario se pueden guardar en un fichero. Por ejemplo, podremos crear un fichero "input.txt" con las siguientes líneas:
```
4
(1,1)
(1,2)
(2,0)
(3,2)
```
Lo anterior debe interpretarse como 4 elementos y sus respectivos valores complejos.

Si el ejecutable dft se lanza como:
```
./bin/dft < input.txt
```
automáticamente leerá los valores del fichero de texto e imprimirá la salida.

# Crear nuevos sets de pruebas

Bastará con crear un fichero con el nombre: "input_XX_elementos.txt" dentro de la carpeta "tests/inputs". Para ejecutarlos, bastará con ejecutar:
```
cd build
cmake ..
make test_input_XX_elementos
```
La salida se creará automáticamente en tests/outputs.

## Ejecutar el programa sin generar un fichero de salida

Bastará ejecutar el siguiente objetivo en la carpeta build:
```
cd build
make test_time_input_XX_elementos
```
Este programa no escribirá la salida a disco.